//
//  AppDelegate.h
//  截图
//
//  Created by liweidong on 17/7/18.
//  Copyright © 2017年 Sillen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

